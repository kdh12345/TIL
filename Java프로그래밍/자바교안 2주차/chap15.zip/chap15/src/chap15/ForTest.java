package chap15;

import java.util.ArrayList;

public class ForTest {

	public static void main(String[] args) {
		//arr 5개 문자열 저장 선언 - 고정 크기
		String [] arr = {"java", "db", "web client", "web server", "ai"};
		for(int i = 0; i < arr.length; i++) {
			System.out.println(arr[i]);
		}
		//jdk 1.5 개선된 반복문
		for(String s : arr ) {
			System.out.println(s.toUpperCase());
		}
		
		System.out.println("===============================================");
		// 1. 여러가지 타입 저장 또는 2.String 타입만 저장(동적 크기의 String 배열)
		ArrayList<String> list = new ArrayList<String>(5);
		list.add("java");
		list.add("db");
		list.add("web client");
		list.add("web server");
		list.add("ai");
		list.add("spring");
		list.add(100);
		for(int i = 0; i < list.size();i++) {
			System.out.println(list.get(i));
		}
		for(String s : list ) {
			System.out.println(s.toUpperCase());
			//if(s instanceof String) {
			//System.out.println( ((String)s).toUpperCase());
			//}

		}
	}

}
