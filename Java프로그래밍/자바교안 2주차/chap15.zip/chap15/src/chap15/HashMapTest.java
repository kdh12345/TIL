package chap15;

import java.util.HashMap;
import java.util.Set;

public class HashMapTest {

	public static void main(String[] args) {
		// generic + 개선된 for
		HashMap<String, Employee> map = new HashMap<String, Employee>();
		Employee e1 = new Employee(100, "이사원", 56000.77);
		
		map.put("사원1", e1);
		map.put("사원2", new Employee(200, "박사원", 56000.77));
		map.put("사원3", new Employee(300, "김사원", 56000.77));
		map.put("사원1", new Employee(400, "최사원", 56000.77));//키중복은 수정효과
		map.put("사원4", e1);//값중복 허용
		//map.put(1, 2);
		System.out.println("갯수=" + map.size());
		
		//3번째 데이터(x) -> 사원3 의 정보를 출력
		Employee o = map.get("사원3");
		System.out.println( o.name );
		//if(o instanceof Employee) {
	//		System.out.println( ((Employee)o).name );
	//	}
	    
		//map 모든 key 조회
		Set keys = map.keySet();
		for(Object k : keys) {
			System.out.println("키는 " + k + " 이고 값은 " + map.get(k));
		}
		
	}

}
