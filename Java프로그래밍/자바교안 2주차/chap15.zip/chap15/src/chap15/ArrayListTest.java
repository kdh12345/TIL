package chap15;

import java.util.ArrayList;
class Employee{
	int id;
	String name;
	double pay;
	Employee(int id, String name, double pay){
		this.id = id;
		this.name = name;
		this.pay = pay;
	}
	@Override
	public String toString() {
		return id + "-" + name + "-" + pay;
	}
	
}
public class ArrayListTest {

	public static void main(String[] args) {
	 //ArrayList<Employee> list = new ArrayList<Employee>(5);
	
	ArrayList<Employee> list = new ArrayList(5);
	
	// 아니다 ArrayList list = new ArrayList<Employee>(5);
	
	/* list.add("java");
	 list.add(100);
	 list.add(3.14);
	 list.add("jsp");
	 list.add(true);//5
	 list.add('a');//
	*/
	 Employee e1 = new Employee(100, "김사원", 67000.88);
	 list.add(e1);
	 Employee e2 = new Employee(200, "박대리", 77000.88);
	 list.add(e2);
	 Employee e3 = new Employee(300, "최과장", 87000.88);
	 list.add(e3);
	 System.out.println(list.size());
	 
	 //add(Object o) 정의 / Object <-get(int)
	 //6 위치의 값= id변수값-name변수값-pay변수값 출력 
	 for(int i=0; i < list.size(); i++) {
		/* if(list.get(i) instanceof Employee) {
			 ((Employee)list.get(i)).name
		 }*/
		 System.out.println(i + " 위치의 값=" + list.get(i).name);
	 }
	}

}
/*	 //컬렉션 프레임워크 기본형변수 x, 객체들만 저장 o
	 // jdk 1.5 이후 추가 -- int 타입 Integer 타입 같은 타입 간주 = autoboxing / auto unboxing
	 // 기본-->참조클래스
	 int i = 100;  // i + i
	 Integer in = new Integer(100);  
	 Integer in2 = 100;//autoboxing
	 int i2 = new Integer(100);//auto unboxing*/