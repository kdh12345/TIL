package chap15;

import java.util.HashSet;

import java.util.Iterator;

public class HashSetTest {

	public static void main(String[] args) {
		HashSet<Integer> set = new HashSet();
		System.out.println("셋 데이터 존재하지 않는지의 여부= " + set.isEmpty());
		set.add(100);
		set.add((int)3.14);
		//set.add("settest");
		set.add(new Employee(100, "이사원", 56000.11).id);
		set.add(100);//무시
		boolean b = set.remove(1);// 1 정수데이터 삭제- 존재하지 않으므로 false
		System.out.println(b);
		System.out.println("갯수="+set.size());
		System.out.println("100 존재하는지의 여부=" + set.contains(100));
		//set 내부 모든 데이터값 조회
		/*
100-이사원-56000.11
100
3.14
settest*/
/*		Iterator it =  set.iterator();//반복자
		//set 내부 데이터를 객체 저장 
		while(it.hasNext()) {//다음 데이터 존재하는지 
			System.out.println(it.next());//다음 데이터 읽어 
		}
*/		
		System.out.println("==============================");
		
		for(Object o : set) {
			System.out.println(o);
		}

		
// add / size /contains - List 동일 메소드
		
	}

}
