import java.util.HashMap;
import java.util.Set;

public class PhoneMapTest {

	public static void main(String[] args) {
		
		String names[] = {"우리엄마", "내친구", "회사동료", "내동생"}; 
		String phon1[] = {"010-1234-5678", "02-111-222", "umma@multi.com"};
		String phon2[] = {"010-9876-5432", "02-123-4567", "031-3333-44444", "myfriend@multi.com"};
		String phon3[] = {"010-1212-4444", "02-6775-5656", "company@multi.com"};
		String phon4[] = {"010-1111-5678"};
		//names배열문자열 - key
		//names[0] value = phone1 배열값들
		HashMap<String, String[]> phone = new HashMap();
		phone.put(names[0], phon1);
		phone.put(names[1], phon2);
		phone.put(names[2], phon3);
		phone.put(names[3], phon4);
		
		//phone 모든값 출력
		//우리엄마 - "010-1234-5678", "02-111-222", "umma@multi.com"
		//내친구 - "010-9876-5432", "02-123-4567", "031-3333-44444", "myfriend@multi.com"
		//....
		Set<String> key = phone.keySet();
		for(String s : key) {
			System.out.print(s + " - ");
			String[] p = phone.get(s);
			for(String sp : p) {
				System.out.print(sp + " , ");
			}
			System.out.println();
		}
		
		// 명령행 매개변수로 우리엄마 입력시 우리엄마 폰정보만 출력
		// 입력 key 존재하지 않으면 해당 정보는 입력된 적이 없습니다 출력
	/*	boolean b = phone.containsKey(args[0]);
		if(b == true) {
			String [] result = phone.get(args[0]);
			for(String r : result) {
				System.out.print(r + " ");
			}
			System.out.println();
		}
		else {
			System.out.println("해당 정보는 입력된 적이 없습니다");
		}
		*/
		String [] result = phone.get(args[0]);
		if( result != null) {
			for(String r : result) {
				System.out.print(r + " ");
			}
			System.out.println();
		}
		else { // result==null
			System.out.println("해당 정보는 입력된 적이 없습니다");
		}
		
}
}