import java.util.HashSet;
import java.util.Iterator;

public class LottoSetTest {

	public static void main(String[] args) {
		HashSet<Integer> lotto = new HashSet();
		while(true) {
			int ran = (int)(Math.random() * 45) + 1;
			System.out.println(ran);
		    lotto.add(ran);
		    if(lotto.size() == 6) { break; }
		}
		//출력
		System.out.println(lotto.size());//6
		
		System.out.print("나의 로또 번호는 (");
		//for(Integer o : lotto) {
		//	System.out.print(o + " ");
		//}
		
		Iterator<Integer> it = lotto.iterator();//set 내부 데이터 복사 저장-반복
		while(it.hasNext()) {
			System.out.print(it.next().parseInt("") + " ");
		}
		System.out.println(") 입니다.");
		
		//set 중복 데이터 저장 무시
		//lotto 1-45 난수 생성 갯수는 6개 이상일 수도 있다. lotto 6개만 저장 
		// 45 34 23 12 1 45 
		//출력
		//나의 로또 번호는 (lotto 저장 데이터들 6개) 입니다


	}

}
