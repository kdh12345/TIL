package mybatis;

import java.io.IOException;
import java.util.List;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

public class MemberMain {

	public static void main(String[] args) throws IOException {
		SqlSessionFactoryBuilder builder = new SqlSessionFactoryBuilder();//설정파일 읽을 준비
		SqlSessionFactory factory = builder.build
				( Resources.getResourceAsReader("mybatis/mybatis-config.xml") );
		//db 연결
		SqlSession session = factory.openSession();
		
		//sql 실행
		List<MemberDTO> list = session.selectList("member.memberlist");
		
		//조회
		for(MemberDTO dto :list) {
			System.out.println(dto);
		}

	}

}
