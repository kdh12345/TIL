package tv;

public interface TV {
	void powerOn();
	void powerOff();
	void volumeUp(int v);
	void volumeDown(int v);
}
