package memberservice;

public interface MemberService {
	public void registerMember();
}
