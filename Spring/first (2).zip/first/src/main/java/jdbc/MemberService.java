package jdbc;

public interface MemberService {
	public String registerMember(MemberDTO dto);
}
