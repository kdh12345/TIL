package ajax;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import board.spring.mybatis.MemberDTO;
import board.spring.mybatis.MemberService;

@Controller
public class LoginAjaxController2 {
	@Qualifier("service")
	@Autowired
	MemberService service;
	
	@GetMapping("/loginajax2")
	public String loginform() {
		return "ajax/loginform2";
	}
	//@ResponseBody 
	@PostMapping(value="/loginajax2" , produces = {"application/json;charset=utf-8"})
	public @ResponseBody MemberDTO loginresult(MemberDTO dto) {
		// db member테이블 해당 id 있으면 그 정보를 가져와서 MemberDTO 리턴
		if(dto.getPassword() == 1234 && dto.getId().equals("ajax")) {
			dto.setName("이동기");
			dto.setPhone("01099990000");
			dto.setEmail("dong@a.co.kr");
			dto.setRegdate("2022-08-25");
		}
		return dto;  //MemberDTO = JSON 자동변환 라이브러리
		// "{\"id\": \"" + dto.getId() + "\" , "password" : dto.getPassword}"
		//pom.xml ,
		
	}
	
	@ResponseBody
	@RequestMapping("/memberlistajax")
	public List<MemberDTO> memberlist(){
		List<MemberDTO> memberlist = service.memberlist();
		return memberlist;
		/* "[{\"id\": \"" + dto.getId() + "\" , "password" :....},
		 * {\"id\": \"" + dto.getId() + "\" , "password" :....},
		 * {\"id\": \"" + dto.getId() + "\" , "password" :....},
		 * ...]
		 *    */
		
	}
	
	
	
	
	
	
	
}
