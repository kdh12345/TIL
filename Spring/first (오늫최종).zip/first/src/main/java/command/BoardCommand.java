package command;

public class BoardCommand implements Command {

	@Override
	public void run() {
		System.out.println("게시판 : 실행중입니다. ");

	}

}
