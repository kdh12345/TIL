package command;

public interface Command {
	void run();
}
