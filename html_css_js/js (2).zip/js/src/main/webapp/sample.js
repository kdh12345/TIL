/**
 * 
 */
 
 var j = 20;
 alert(j);